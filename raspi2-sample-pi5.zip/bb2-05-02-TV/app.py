import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import subprocess

app = FastAPI()
app.mount(path="/5-2/static", app=StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get('/5-2/get/{group}/{command}')
async def get(group: str, command: str):
    args = ['irsend', '-#', '1', 'SEND_ONCE', group, command]
    subprocess.Popen(args)

    return command

@app.get('/5-2', response_class=HTMLResponse)
async def index(request: Request):
    context = {"request": request}
    return templates.TemplateResponse("index.html", context)

uvicorn.run(app, host='0.0.0.0', port=8000)
