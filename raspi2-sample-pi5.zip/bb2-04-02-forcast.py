import requests
import json

lat = '35.6895'
lon = '139.6917'
exclude = 'current,minutely,hourly,alerts'
key = 'API_KEY'

units = 'metric'
lang = 'ja'

address = 'http://api.openweathermap.org/data/2.5/onecall?lat={lat}&lon={lon}&exclude={exclude}&appid={key}&units={units}&lang={lang}'.format(lat=lat, lon=lon, exclude=exclude, key=key, units=units, lang=lang)
weather_json = requests.get(address).json()

dataLabel = ['今日', '明日', '明後日']
weather_dict = {'Clear':'晴れ', 'Clouds':'曇り', 'Rain':'雨','Snow':'雪', 'Thunderstorm':'雷', 'Drizzle':'霧'}

for i in range(3):
    forecast = weather_json['daily'][i]
    temp_min = round(forecast['temp']['min'])
    temp_max = round(forecast['temp']['max'])
    try:
        weather = weather_dict[forecast['weather'][0]['main']]
    except KeyError:
        weather = '未定義'

    print('{}, {}, {}/{}'.format(dataLabel[i], weather, temp_min, temp_max))
