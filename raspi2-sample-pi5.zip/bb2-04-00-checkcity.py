import requests
import json

city = 'Tokyo'
key = 'API_KEY'

address = 'http://api.openweathermap.org/data/2.5/weather?units=metric&q={city}&APPID={key}'.format(city=city, key=key)

weather_json = requests.get(address).json()

print(city)
try:
    print('lat = \'{}\''.format(weather_json['coord']['lat']))
    print('lon = \'{}\''.format(weather_json['coord']['lon']))
except KeyError:
    print('Not found.')
