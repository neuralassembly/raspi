from gpiozero import DigitalOutputDevice, Button
from time import sleep
import random
from signal import pause

def my_callback(button):
    if button.pin.number == 22: 
        dice = random.randint(1,6)
        if dice == 1:
            sendLEDdata(LEDdata1, ser, rclk, srclk)
        elif dice == 2:
            sendLEDdata(LEDdata2, ser, rclk, srclk)
        elif dice == 3:
            sendLEDdata(LEDdata3, ser, rclk, srclk)
        elif dice == 4:
            sendLEDdata(LEDdata4, ser, rclk, srclk)
        elif dice == 5:
            sendLEDdata(LEDdata5, ser, rclk, srclk)
        elif dice == 6:
            sendLEDdata(LEDdata6, ser, rclk, srclk)

def sendLEDdata(data, ser, rclk, srclk):
    n = len(data)

    rclk.value = 0
    srclk.value = 0

    for i in range(n):
        if data[i] == 1:
            ser.value = 1
        else:
            ser.value = 0

        srclk.value = 1
        srclk.value = 0

    rclk.value = 1
    rclk.value = 0

ser = DigitalOutputDevice(25)
rclk = DigitalOutputDevice(24)
srclk = DigitalOutputDevice(23)
btn = Button(22, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(22, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)

btn.when_pressed = my_callback

LEDdata0 = [0,  0,
            0,0,0,
            0,  0]
LEDdata1 = [0,  0,
            0,1,0,
            0,  0]
LEDdata2 = [0,  1,
            0,0,0,
            1,  0]
LEDdata3 = [0,  1,
            0,1,0,
            1,  0]
LEDdata4 = [1,  1,
            0,0,0,
            1,  1]
LEDdata5 = [1,  1,
            0,1,0,
            1,  1]
LEDdata6 = [1,  1,
            1,0,1,
            1,  1]

sendLEDdata(LEDdata0, ser, rclk, srclk)

try:
    pause()
except KeyboardInterrupt:
    pass
