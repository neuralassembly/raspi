try:
    import sklearn
    print('scikit-learnのバージョンは{0}です'.format(sklearn.__version__))
    del sklearn
except ImportError:
    print('scikit-learnはインストールされていません')

try:
    import numpy
    print('numpyのバージョンは{0}です'.format(numpy.__version__))
    del numpy
except ImportError:
    print('numpyはインストールされていません')

try:
    import scipy
    print('scipyのバージョンは{0}です'.format(scipy.__version__))
    del scipy
except ImportError:
    print('scipyはインストールされていません')

try:
    import matplotlib
    print('matplotlibのバージョンは{0}です'.format(matplotlib.__version__))
    del matplotlib
except ImportError:
    print('matplotlibはインストールされていません')

try:
    from PIL import Image
    try:
        import PIL
        print('PIL(Pillow)のバージョンは{0}です'.format(PIL.__version__))
        del PIL
    except AttributeError:
        print('PIL(Pillow)のバージョンは{0}です'.format(Image.PILLOW_VERSION))
    del Image
except ImportError:
    print('PIL(Pillow)はインストールされていません')

try:
    import cv2
    print('OpenCVのバージョンは{0}です'.format(cv2.__version__))
    del cv2
except ImportError:
    print('OpenCVはインストールされていません')

try:
    import keras
    print('kerasのバージョンは{0}です'.format(keras.__version__))
except (ImportError, AttributeError):
    print('kerasはインストールされていません')

try:
    import tensorflow as tf
    print('tensorflowのバージョンは{0}です'.format(tf.__version__))
except (ImportError, AttributeError):
    print('tensorflowはインストールされていません')
