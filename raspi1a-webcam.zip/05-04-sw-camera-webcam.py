import RPi.GPIO as GPIO
from time import sleep
import datetime
import threading
import sys
import cv2

version = cv2.__version__.split(".")
CVversion = int(version[0])

cap = cv2.VideoCapture(0)

if CVversion == 2:
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.cv.CV_CAP_PROP_FPS, 15)
else:
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 15)

ret, frame = cap.read()

capturing = False
def takingPicture():
    global capturing
    d = datetime.datetime.today()
    filename = "{0}{1:02d}{2:02d}-{3:02d}{4:02d}{5:02d}.jpg".format(d.year, d.month, d.day, d.hour, d.minute, d.second)
    capturing = True
    cv2.imwrite(filename, frame)
    capturing = False

def my_callback(channel):
    if channel==27:
        t = threading.Thread(target=takingPicture)
        t.start()

GPIO.setmode(GPIO.BCM)
GPIO.setup(27, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.add_event_detect(27, GPIO.RISING, callback=my_callback, bouncetime=200)

try:
    while True:
        if not capturing:
            ret, frame = cap.read()
        # frameをウインドウに表示
        cv2.imshow('frame', frame)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cap.release()
GPIO.cleanup()
