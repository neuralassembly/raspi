import cv2
from picamera2 import Picamera2
import math
import os
import sys
from time import sleep

(w, h)=(640, 480)

def pwm_check():
    global chipid, pwmchip, isPi5, pwmid0, pwmid1
    if not os.access(pwmchip, os.F_OK):
        chipid = 0 # Pi 1-4
        pwmid0 = 0 # Pi 1-4, GPIO18
        pwmid1 = 1 # Pi 1-4, GPIO19
        pwmchip = '/sys/class/pwm/pwmchip{}'.format(chipid)
        isPi5 = False
        if not os.access(pwmchip, os.F_OK):
            print('{},4 do not exist. \'dtoverlay=pwm-2chan\' in /boot/config.txt is required. '.format(pwmchip))
            sys.exit()

def pwm_open(pwmid):
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmexp = '{}/export'.format(pwmchip)
    if not os.path.isdir(pwmdir):
        with open(pwmexp, 'w') as f:
            f.write('{}\n'.format(pwmid))
    sleep(0.3)

def pwm_freq(pwmid, freq): # Hz
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmperiod = '{}/period'.format(pwmdir)
    period = int(1000000000/freq)
    with open(pwmperiod, 'w') as f:
        f.write('{}\n'.format(period))

def pwm_duty(pwmid, duty): # ms
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmduty = '{}/duty_cycle'.format(pwmdir)
    dutyns = int(1000000*duty)
    with open(pwmduty, 'w') as f:
        f.write('{}\n'.format(dutyns))

def pwm_enable(pwmid):
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmenable = '{}/enable'.format(pwmdir)
    with open(pwmenable, 'w') as f:
        f.write('1\n')

def pwm_disable(pwmid):
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmenable = '{}/enable'.format(pwmdir)
    with open(pwmenable, 'w') as f:
        f.write('0\n')

def getServoDutyHw(id, val):
    val_min = 0
    val_max = 1
    servo_min = 0.7 # ms
    servo_max = 2.0 # ms
    if id==1:
        servo_min = 1.03 # ms
        servo_max = 1.67 # ms
    duty = (servo_min-servo_max)*(val-val_min)/(val_max-val_min) + servo_max
    # 一般的なサーボモーターはこちらを有効に
    #duty = (servo_max-servo_min)*(val-val_min)/(val_max-val_min) + servo_min
    if duty > servo_max:
        duty = servo_max
    if duty < servo_min:
        duty = servo_min
    return duty

isPi5 = True
chipid = 2 # Pi5
pwmid0 = 2 # Pi5, GPIO18
pwmid1 = 3 # Pi5, GPIO19
pwmchip = '/sys/class/pwm/pwmchip{}'.format(chipid)

pwm_check()

pwm_open(pwmid0)
pwm_freq(pwmid0, 50) #Hz
pwm_duty(pwmid0, 1.35) #ms
pwm_enable(pwmid0)

pwm_open(pwmid1)
pwm_freq(pwmid1, 50) #Hz
pwm_duty(pwmid1, 1.35) #ms
pwm_enable(pwmid1)

picam2 = Picamera2()
try:
    # camver=1 or camver=2
    camver = 1
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[3])
except IndexError:
    try:
        camver=3
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[2])
    except IndexError:
        camver=0
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)})
picam2.configure(preview_config)
picam2.start()

wc = int(w/2)
hc = int(h/2)
prev_x = wc
prev_y = hc
prev_input_x = 0.5
prev_input_y = 0.5
blurval = min(int(16*(w/640)), 24)
blurval = blurval + (1 - blurval%2)
mincdist = int(100*(w/640))
mincradius = int(10*(w/640))
maxcradius = int(200*(w/640))
# サーボモーターを回転させる量を決める定数
ratio_x =  640/w/4096
ratio_y = -480/h/4096
try:
    while True:
        frame = picam2.capture_array()

        # 映像データをグレースケール画像grayに変換
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # ガウシアンぼかしを適用して、認識精度を上げる
        blur = cv2.GaussianBlur(gray, (blurval,blurval), 0)
        # ハフ変換を適用し、映像内の円を探す
        circles = cv2.HoughCircles(blur, cv2.HOUGH_GRADIENT,
              dp=1, minDist=mincdist, param1=120, param2=40,
              minRadius=mincradius, maxRadius=maxcradius)

        if circles is not None:
            # 複数見つかった円のうち、以前の円の位置に最も近いものを探す
            mindist = w + h
            minindx = 0
            indx = 0
            for c in circles[0]:
                dist = math.fabs(c[0]-prev_x) + math.fabs(c[1]-prev_y)
                if dist < mindist:
                    mindist = dist
                    minindx = indx
                indx += 1

            # 現在の円の位置
            circle_x = circles[0][minindx][0]
            circle_y = circles[0][minindx][1]

            # 現在の円の位置に赤い円を元の映像(frame)上に描画
            cv2.circle(frame, (int(circle_x), int(circle_y)),
                  int(circles[0][minindx][2]), (0,0,255), 2)

            dx = circle_x-wc  # 左右中央からのずれ
            dy = circle_y-hc  # 上下中央からのずれ

            duty0 = getServoDutyHw(0, ratio_x*dx + prev_input_x)
            pwm_duty(pwmid0, duty0)
    
            duty1 = getServoDutyHw(1, ratio_y*dy + prev_input_y)
            pwm_duty(pwmid1, duty1)

            # サーボモーターに対する入力値を更新
            prev_input_x = ratio_x*dx + prev_input_x
            if prev_input_x > 1:
                prev_input_x = 1
            if prev_input_x < 0:
                prev_input_x = 0
            prev_input_y = ratio_y*dy + prev_input_y
            if prev_input_y > 1:
                prev_input_y = 1
            if prev_input_y < 0:
                prev_input_y = 0

            # 以前の円の位置を更新
            prev_x = circle_x
            prev_y = circle_y

        # frameをウインドウに表示
        cv2.imshow('frame', frame)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cv2.destroyAllWindows()
