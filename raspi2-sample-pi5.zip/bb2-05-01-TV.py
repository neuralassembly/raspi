from gpiozero import Button
from time import sleep
import subprocess
from signal import pause

def my_callback(button):
    if button.pin.number == 23:
        args = ['irsend', '-#', '1', 'SEND_ONCE', 'TV', 'power']
        subprocess.Popen(args)
    elif button.pin.number == 22:
        args = ['irsend', '-#', '1', 'SEND_ONCE', 'TV', 'cup']
        subprocess.Popen(args)
    elif button.pin.number == 27:
        args = ['irsend', '-#', '1', 'SEND_ONCE', 'TV', 'cdown']
        subprocess.Popen(args)
    elif button.pin.number == 17:
        args = ['irsend', '-#', '1', 'SEND_ONCE', 'TV', 'vup']
        subprocess.Popen(args)
    elif button.pin.number == 18:
        args = ['irsend', '-#', '1', 'SEND_ONCE', 'TV', 'vdown']
        subprocess.Popen(args)

btn = Button(23, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(23, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)
btn.when_pressed = my_callback

btn = Button(22, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(22, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)
btn.when_pressed = my_callback

btn = Button(27, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(27, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)
btn.when_pressed = my_callback

btn = Button(17, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(17, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)
btn.when_pressed = my_callback

btn = Button(18, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(18, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)
btn.when_pressed = my_callback

try:
    pause()
except KeyboardInterrupt:
    pass

