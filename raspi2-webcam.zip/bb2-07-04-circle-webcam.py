# -*- coding: utf-8 -*-
import cv2

version = cv2.__version__.split(".")
CVversion = int(version[0])

cap = cv2.VideoCapture(0)

if CVversion == 2:
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, 240)
    cap.set(cv2.cv.CV_CAP_PROP_FPS, 15)
else:
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
    cap.set(cv2.CAP_PROP_FPS, 15)

while True:
    ret, frame = cap.read()

    # 映像データをグレースケール画像grayに変換
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # ガウシアンぼかしを適用して、認識精度を上げる
    blur = cv2.GaussianBlur(gray, (9,9), 0)
    # ハフ変換を適用し、映像内の円を探す
    if CVversion == 2:
        circles = cv2.HoughCircles(blur, cv2.cv.CV_HOUGH_GRADIENT,
              dp=1, minDist=50, param1=120, param2=40,
              minRadius=5, maxRadius=100)
    else:
        circles = cv2.HoughCircles(blur, cv2.HOUGH_GRADIENT,
              dp=1, minDist=50, param1=120, param2=40,
              minRadius=5, maxRadius=100)

    if circles is not None:
        for c in circles[0]:
            # 見つかった円の上に赤い円を元の映像(frame)上に描画
            # c[0]:x座標, c[1]:y座標, c[2]:半径
            cv2.circle(frame, (int(c[0]),int(c[1])), int(c[2]), (0,0,255), 2)

    # system.arrayをウインドウに表示
    cv2.imshow('frame', frame)

    # "q"を入力でアプリケーション終了
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
