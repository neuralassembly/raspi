var url_base = '/5-2/get/';

function sendCommand(group, command) {
    var url = url_base + group + '/' + command;
    fetch(url);
}
