# -*- coding: utf-8 -*-
import cv2
from picamera2 import Picamera2

camver = 1
(w, h)=(640, 480)

picam2 = Picamera2()
if camver==1 or camver==2:
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[3])
elif camver==3:
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[2])
else:
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)})
picam2.configure(preview_config)
picam2.start()

try:
    while True:
        frame = picam2.capture_array()

        # 映像データをグレースケール画像grayに変換
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Cannyフィルタを適用し、結果をedgeに格納
        edge = cv2.Canny(gray, 50, 100)
        # edgeをウインドウに表示
        cv2.imshow('frame', edge)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cv2.destroyAllWindows()
