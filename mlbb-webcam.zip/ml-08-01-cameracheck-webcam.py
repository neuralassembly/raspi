# -*- coding: utf-8 -*-
import cv2

(w, h)=(320, 240)

version = cv2.__version__.split(".")
CVversion = int(version[0])

cap = cv2.VideoCapture(0)

if CVversion == 2:
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, w)
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, h)
    cap.set(cv2.cv.CV_CAP_PROP_FPS, 15)
else:
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
    cap.set(cv2.CAP_PROP_FPS, 15)

while True:
    ret, frame = cap.read()

    # frameをウインドウに表示
    cv2.imshow('frame', frame)

    # 'q'を入力でアプリケーション終了
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

