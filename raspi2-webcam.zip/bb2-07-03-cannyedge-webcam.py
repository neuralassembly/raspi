# -*- coding: utf-8 -*-
import cv2

version = cv2.__version__.split(".")
CVversion = int(version[0])

cap = cv2.VideoCapture(0)

if CVversion == 2:
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, 240)
    cap.set(cv2.cv.CV_CAP_PROP_FPS, 15)
else:
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
    cap.set(cv2.CAP_PROP_FPS, 15)

while True:
    ret, frame = cap.read()

    # 映像データをグレースケール画像grayに変換
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Cannyフィルタを適用し、結果をedgeに格納
    edge = cv2.Canny(gray, 50, 100)
    # edgeをウインドウに表示
    cv2.imshow('frame', edge)

    # "q"を入力でアプリケーション終了
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
