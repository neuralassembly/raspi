function sendCommand(group, command){
    // script.py内のsendCommand関数を実行。
    webiopi().callMacro("sendCommand", [group, command]);
}

var url_base = '/get/';

function sendCommand(group, command) {
    var url = url_base + group + '/' + command;
    fetch(url)
}
