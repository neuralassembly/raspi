import requests
import json

lat = '35.6895'
lon = '139.6917'
exclude = 'current,minutely,hourly,alerts'
key = 'API_KEY'

units = 'metric'
lang = 'ja'

address = 'http://api.openweathermap.org/data/2.5/onecall?lat={lat}&lon={lon}&exclude={exclude}&appid={key}&units={units}&lang={lang}'.format(lat=lat, lon=lon, exclude=exclude, key=key, units=units, lang=lang)

weather_json = requests.get(address).json()
print(json.dumps(weather_json, indent=2, ensure_ascii=False))
