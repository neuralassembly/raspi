import cv2
import os
from picamera2 import Picamera2
import math
import os
import sys
from time import sleep

camver = 1
(w, h)=(640, 480)

cascade_path =  "/usr/share/opencv/haarcascades/haarcascade_frontalface_alt.xml"
if not os.path.isfile(cascade_path):
    cascade_path =  "/usr/share/opencv4/haarcascades/haarcascade_frontalface_alt.xml"
cascade = cv2.CascadeClassifier(cascade_path)

def pwm_check():
    global chipid, pwmchip, isPi5, pwmid0, pwmid1
    if not os.access(pwmchip, os.F_OK):
        chipid = 0 # Pi 1-4
        pwmid0 = 0 # Pi 1-4, GPIO18
        pwmid1 = 1 # Pi 1-4, GPIO19
        pwmchip = '/sys/class/pwm/pwmchip{}'.format(chipid)
        isPi5 = False
        if not os.access(pwmchip, os.F_OK):
            print('{},4 do not exist. \'dtoverlay=pwm-2chan\' in /boot/config.txt is required. '.format(pwmchip))
            sys.exit()

def pwm_open(pwmid):
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmexp = '{}/export'.format(pwmchip)
    if not os.path.isdir(pwmdir):
        with open(pwmexp, 'w') as f:
            f.write('{}\n'.format(pwmid))
    sleep(0.3)

def pwm_freq(pwmid, freq): # Hz
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmperiod = '{}/period'.format(pwmdir)
    period = int(1000000000/freq)
    with open(pwmperiod, 'w') as f:
        f.write('{}\n'.format(period))

def pwm_duty(pwmid, duty): # ms
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmduty = '{}/duty_cycle'.format(pwmdir)
    dutyns = int(1000000*duty)
    with open(pwmduty, 'w') as f:
        f.write('{}\n'.format(dutyns))

def pwm_enable(pwmid):
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmenable = '{}/enable'.format(pwmdir)
    with open(pwmenable, 'w') as f:
        f.write('1\n')

def pwm_disable(pwmid):
    pwmdir = '{}/pwm{}'.format(pwmchip, pwmid)
    pwmenable = '{}/enable'.format(pwmdir)
    with open(pwmenable, 'w') as f:
        f.write('0\n')

def getServoDutyHw(id, val):
    val_min = 0
    val_max = 1
    servo_min = 0.7 # ms
    servo_max = 2.0 # ms
    if id==1:
        servo_min = 1.03 # ms
        servo_max = 1.67 # ms
    duty = (servo_min-servo_max)*(val-val_min)/(val_max-val_min) + servo_max
    # 一般的なサーボモーターはこちらを有効に
    #duty = (servo_max-servo_min)*(val-val_min)/(val_max-val_min) + servo_min
    if duty > servo_max:
        duty = servo_max
    if duty < servo_min:
        duty = servo_min
    return duty

isPi5 = True
chipid = 2 # Pi5
pwmid0 = 2 # Pi5, GPIO18
pwmid1 = 3 # Pi5, GPIO19
pwmchip = '/sys/class/pwm/pwmchip{}'.format(chipid)

pwm_check()

pwm_open(pwmid0)
pwm_freq(pwmid0, 50) #Hz
pwm_duty(pwmid0, 1.35) #ms
pwm_enable(pwmid0)

pwm_open(pwmid1)
pwm_freq(pwmid1, 50) #Hz
pwm_duty(pwmid1, 1.35) #ms
pwm_enable(pwmid1)

picam2 = Picamera2()
try:
    # camver=1 or camver=2
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[3])
except IndexError:
    try:
        camver=3
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[2])
    except IndexError:
        camver=0
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)})
picam2.configure(preview_config)
picam2.start()

minsize = int(60*(w/640))
maxsize = int(300*(w/640))
wc = int(w/2)
hc = int(h/2)
prev_x = wc
prev_y = hc
prev_input_x = 0.5
prev_input_y = 0.5
# サーボモーターを回転させる量を決める定数
ratio_x =  640/w/4096
ratio_y = -480/h/4096
try:
    while True:
        frame = picam2.capture_array()

        # 映像データをグレースケール画像grayに変換
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # grayから顔を探す
        facerect = cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=2, minSize=(minsize,minsize), maxSize=(maxsize,maxsize))

        if len(facerect) > 0:
            # 複数見つかった顔のうち、以前の顔の位置に最も近いものを探す
            mindist = w + h
            minindx = 0
            indx = 0
            for rect in facerect:
                dist = math.fabs(rect[0]+rect[2]/2-prev_x) + math.fabs(rect[1]+rect[3]/2-prev_y)
                if dist < mindist:
                    mindist = dist
                    minindx = indx
                indx += 1

            # 現在の顔の位置
            face_x = facerect[minindx][0]+facerect[minindx][2]/2
            face_y = facerect[minindx][1]+facerect[minindx][3]/2

            # 元の画像(frame)上の、顔がある位置に赤い四角を描画
            cv2.rectangle(frame, tuple(facerect[minindx][0:2]),tuple(facerect[minindx][0:2]+facerect[minindx][2:4]), (0,0,255), thickness=2)

            dx = face_x-wc  # 左右中央からのずれ
            dy = face_y-hc  # 上下中央からのずれ

            duty0 = getServoDutyHw(0, ratio_x*dx + prev_input_x)
            pwm_duty(pwmid0, duty0)

            duty1 = getServoDutyHw(1, ratio_y*dy + prev_input_y)
            pwm_duty(pwmid1, duty1)

            # サーボモーターに対する入力値を更新
            prev_input_x = ratio_x*dx + prev_input_x
            if prev_input_x > 1:
                prev_input_x = 1
            if prev_input_x < 0:
                prev_input_x = 0
            prev_input_y = ratio_y*dy + prev_input_y
            if prev_input_y > 1:
                prev_input_y = 1
            if prev_input_y < 0:
                prev_input_y = 0

            # 以前の顔の位置を更新
            prev_x = face_x
            prev_y = face_y

        # frameをウインドウに表示
        cv2.imshow('frame', frame)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cv2.destroyAllWindows()
