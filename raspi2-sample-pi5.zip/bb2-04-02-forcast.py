import requests
import json

lat = '35.6895'
lon = '139.6917'
units = 'metric'
lang = 'ja'
key = 'API_KEY'

address = 'http://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={key}&units={units}&lang={lang}'.format(lat=lat, lon=lon, key=key, units=units, lang=lang)

weather_json = requests.get(address).json()

dataLabel = ['今日', '明日', '明後日']
weather_dict = {'Clear':'晴れ', 'Clouds':'曇り', 'Rain':'雨','Snow':'雪', 'Thunderstorm':'雷', 'Drizzle':'霧'}

for i in range(3):
    forecast = weather_json['list'][8*i]
    temp_min = round(forecast['main']['temp_min'])
    temp_max = round(forecast['main']['temp_max'])
    when = forecast['dt_txt']
    try:
        weather = weather_dict[forecast['weather'][0]['main']]
    except KeyError:
        weather = '未定義'

    print('{}, {}, {}/{}, {}'.format(dataLabel[i], weather, temp_min, temp_max, when))
