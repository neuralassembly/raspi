import requests
import json

lat = '35.6895'
lon = '139.6917'
units = 'metric'
lang = 'ja'
key = 'API_KEY'

address = 'http://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={key}&units={units}&lang={lang}'.format(lat=lat, lon=lon, key=key, units=units, lang=lang)

weather_json = requests.get(address).json()
print(json.dumps(weather_json, indent=2, ensure_ascii=False))
