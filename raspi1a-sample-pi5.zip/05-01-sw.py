from gpiozero import LED, Button
from time import sleep

led = LED(25)
btn = Button(27, pull_up=None, active_state=True)

try:
    while True:
        if btn.is_pressed:
            led.on()
        else:
            led.off()
        sleep(0.01)

except KeyboardInterrupt:
    pass

led.close()
btn.close()
