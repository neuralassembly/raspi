# -*- coding: utf-8 -*-
import cv2
from picamera2 import Picamera2

camver = 1
(w, h)=(640, 480)

picam2 = Picamera2()
try:
    # camver=1 or camver=2
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[3])
except IndexError:
    try:
        camver=3
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[2])
    except IndexError:
        camver=0
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)})
picam2.configure(preview_config)
picam2.start()

try:
    while True:
        frame = picam2.capture_array()

        # 映像データをグレースケール画像grayに変換
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # 画像の二値化 (閾値127)
        #(ret, binary) = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
        # 画像の二値化 (大津の方法)
        (ret, binary) = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        # retの表示
        print(ret)
        # binaryをウインドウに表示
        cv2.imshow('frame', binary)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cv2.destroyAllWindows()
