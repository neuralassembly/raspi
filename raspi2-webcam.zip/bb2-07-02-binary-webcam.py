# -*- coding: utf-8 -*-
import cv2

(w, h)=(640, 480)

version = cv2.__version__.split(".")
CVversion = int(version[0])

cap = cv2.VideoCapture(0)

if CVversion == 2:
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_WIDTH, w)
    cap.set(cv2.cv.CV_CAP_PROP_FRAME_HEIGHT, h)
    cap.set(cv2.cv.CV_CAP_PROP_FPS, 15)
else:
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
    cap.set(cv2.CAP_PROP_FPS, 15)

while True:
    ret, frame = cap.read()

    # 映像データをグレースケール画像grayに変換
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # 画像の二値化 (閾値127)
    (ret, binary) = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    # 画像の二値化 (大津の方法)
    #(ret, binary) = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    # retの表示
    print(ret)
    # binaryをウインドウに表示
    cv2.imshow('frame', binary)

    # "q"を入力でアプリケーション終了
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
