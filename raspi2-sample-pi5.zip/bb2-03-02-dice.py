from gpiozero import DigitalOutputDevice
from time import sleep

def sendLEDdata(data, ser, rclk, srclk):
    n = len(data)

    rclk.value = 0
    srclk.value = 0

    for i in range(n):
        if data[i] == 1:
            ser.value = 1
        else:
            ser.value = 0

        srclk.value = 1
        srclk.value = 0

    rclk.value = 1
    rclk.value = 0

ser = DigitalOutputDevice(25)
rclk = DigitalOutputDevice(24)
srclk = DigitalOutputDevice(23)

LEDdata1 = [0,  0,
            0,1,0,
            0,  0]
LEDdata2 = [0,  1,
            0,0,0,
            1,  0]
LEDdata3 = [0,  1,
            0,1,0,
            1,  0]
LEDdata4 = [1,  1,
            0,0,0,
            1,  1]
LEDdata5 = [1,  1,
            0,1,0,
            1,  1]
LEDdata6 = [1,  1,
            1,0,1,
            1,  1]

try:
    while True:
        sendLEDdata(LEDdata1, ser, rclk, srclk)
        sleep(1)
        sendLEDdata(LEDdata2, ser, rclk, srclk)
        sleep(1)
        sendLEDdata(LEDdata3, ser, rclk, srclk)
        sleep(1)
        sendLEDdata(LEDdata4, ser, rclk, srclk)
        sleep(1)
        sendLEDdata(LEDdata5, ser, rclk, srclk)
        sleep(1)
        sendLEDdata(LEDdata6, ser, rclk, srclk)
        sleep(1)

except KeyboardInterrupt:
    pass
