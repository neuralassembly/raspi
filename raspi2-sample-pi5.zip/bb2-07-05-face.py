import cv2
import os
from picamera2 import Picamera2

(w, h)=(640, 480)

cascade_path =  "/usr/share/opencv/haarcascades/haarcascade_frontalface_alt.xml"
if not os.path.isfile(cascade_path):
    cascade_path =  "/usr/share/opencv4/haarcascades/haarcascade_frontalface_alt.xml"
cascade = cv2.CascadeClassifier(cascade_path)

picam2 = Picamera2()
try:
    # camver=1 or camver=2
    camver = 1
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[3])
except IndexError:
    try:
        camver=3
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[2])
    except IndexError:
        camver=0
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)})
picam2.configure(preview_config)
picam2.start()

minsize = int(60*(w/640))
maxsize = int(300*(w/640))
try:
    while True:
        frame = picam2.capture_array()

        # 映像データをグレースケール画像grayに変換
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # grayから顔を探す
        facerect = cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=2, minSize=(minsize,minsize), maxSize=(maxsize,maxsize))

        if len(facerect) > 0:
            for rect in facerect:
                # 元の画像(system.array)の顔がある位置赤い四角を描画
                # rect[0:2]:長方形の左上の座標, rect[2:4]:長方形の横と高さ
                # rect[0:2]+rect[2:4]:長方形の右下の座標
                cv2.rectangle(frame, tuple(rect[0:2]),tuple(rect[0:2]+rect[2:4]), (0,0,255), thickness=2)

        # frameをウインドウに表示
        cv2.imshow('frame', frame)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cv2.destroyAllWindows()
