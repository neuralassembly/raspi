from gpiozero import LED, Button
from time import sleep
from signal import pause

def pressed(button):
    if button.pin.number == 27:
        global ledState 
        ledState = not ledState
        #led.value = ledState
        #led.toggle()
        if ledState == 1:
            led.on()
        else:
            led.off()

led = LED(25)
btn = Button(27, pull_up=False, bounce_time=0.05) # for Bookworm (gpiozero 2.0)
#btn = Button(27, pull_up=False, bounce_time=None) # for Bullseye (gpiozero 1.6.2)

btn.when_pressed = pressed
ledState = led.value

try:
    pause()
except KeyboardInterrupt:
    pass

