import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from gpiozero import Servo
from time import sleep
import threading

def setDuty3_0(duty0, duty1, duty2):
    servo0.value = duty0
    servo1.value = duty1
    servo2.value = duty2

def setDuty3_3(duty3, duty4, duty5):
    servo3.value = duty3
    servo4.value = duty4
    servo5.value = duty5

def setDuty6(duty0, duty1, duty2, duty3, duty4, duty5):
    servo0.value = duty0
    servo1.value = duty1
    servo2.value = duty2
    servo3.value = duty3
    servo4.value = duty4
    servo5.value = duty5

def forwardPhase1(delay):
    setDuty3_0(LEG_F_R, LEG_F_R, LEG_F_L)
    sleep(delay)
    setDuty3_3(LEG_B_R, LEG_B_L, LEG_B_L)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def forwardPhase2(delay):
    setDuty3_3(LEG_F_R, LEG_F_L, LEG_F_L)
    sleep(delay)
    setDuty3_0(LEG_B_R, LEG_B_R, LEG_B_L)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def forwardMove(delay):
    forwardPhase1(delay)
    forwardPhase2(delay)

def backwardPhase1(delay):
    setDuty3_0(LEG_B_R, LEG_B_R, LEG_B_L)
    sleep(delay)
    setDuty3_3(LEG_F_R, LEG_F_L, LEG_F_L)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def backwardPhase2(delay):
    setDuty3_3(LEG_B_R, LEG_B_L, LEG_B_L)
    sleep(delay)
    setDuty3_0(LEG_F_R, LEG_F_R, LEG_F_L)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def backwardMove(delay):
    backwardPhase1(delay)
    backwardPhase2(delay)

def rotateRightPhase1(delay):
    setDuty3_0(LEG_B_R, LEG_B_R, LEG_F_L)
    sleep(delay)
    setDuty3_3(LEG_F_R, LEG_B_L, LEG_B_L)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def rotateRightPhase2(delay):
    setDuty3_3(LEG_B_R, LEG_F_L, LEG_F_L)
    sleep(delay)
    setDuty3_0(LEG_F_R, LEG_F_R, LEG_B_L)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def rotateRightMove(delay):
    rotateRightPhase1(delay)
    rotateRightPhase2(delay)

def rotateLeftPhase1(delay):
    setDuty3_0(LEG_F_R, LEG_F_R, LEG_B_L)
    sleep(delay)
    setDuty3_3(LEG_B_R, LEG_F_L, LEG_F_L)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def rotateLeftPhase2(delay):
    setDuty3_3(LEG_F_R, LEG_B_L, LEG_B_L)
    sleep(delay)
    setDuty3_0(LEG_B_R, LEG_B_R, LEG_F_L)
    sleep(delay)
    setDuty3_3(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)
    setDuty3_0(NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def rotateLeftMove(delay):
    rotateLeftPhase1(delay)
    rotateLeftPhase2(delay)

def stopMove(delay):
    setDuty6(NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL, NEUTRAL)
    sleep(delay)

def processCommands():
    global status

    while True:
        if status == 'i':
            sleep(DELAY)
        elif status == 'f':
            forwardMove(DELAY)
        elif status == 'b':
            backwardMove(DELAY)
        elif status == 'r':
            rotateRightMove(DELAY)
        elif status == 'l':
            rotateLeftMove(DELAY)
        elif status == 's':
            stopMove(DELAY)
            status = 'i'
        elif status == 'k':
            break

servo0 = Servo(25)
servo1 = Servo(24)
servo2 = Servo(23)
servo3 = Servo(22)
servo4 = Servo(27)
servo5 = Servo(18)

servo0.value = 0
servo1.value = 0
servo2.value = 0
servo3.value = 0
servo4.value = 0
servo5.value = 0

NEUTRAL = 0
LEG_F_R = NEUTRAL + 0.72
LEG_F_L = NEUTRAL - 0.72
LEG_B_R = NEUTRAL - 0.72
LEG_B_L = NEUTRAL + 0.72

DELAY = 0.15

# i:idle, f: forward, b: backward, r: right, l: left, s: stop, k: kill
status = 'i'

stopMove(DELAY)

t = threading.Thread(target=processCommands)
t.start()

app = FastAPI()
app.mount(path="/static", app=StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get('/get/{command}')
async def get(command: str):
    global status
    status = command
    return command

@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    context = {"request": request}
    return templates.TemplateResponse("index.html", context)

try:
    uvicorn.run(app, host='0.0.0.0', port=8000)
except KeyboardInterrupt:
    pass

status = 'k'
t.join()
