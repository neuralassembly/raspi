from gpiozero import DigitalInputDevice, DigitalOutputDevice
from time import sleep

# MCP3208からSPI通信で12ビットのデジタル値を取得。0から7の8チャンネル使用可
def readadc(adcnum, spiclk, spimosi, spimiso, spics):
    if adcnum > 7 or adcnum < 0:
        return -1
    spics.value = 1
    spiclk.value = 0
    spics.value = 0

    commandout = adcnum
    commandout |= 0x18  # スタートビット＋シングルエンドビット
    commandout <<= 3    # LSBから8ビット目を送信するようにする
    for i in range(5):
        # LSBから数えて8ビット目から4ビット目までを送信
        if commandout & 0x80:
            spimosi.value = 1
        else:
            spimosi.value = 0
        commandout <<= 1
        spiclk.value = 1
        spiclk.value = 0
    adcout = 0
    # 13ビット読む（ヌルビット＋12ビットデータ）
    for i in range(13):
        spiclk.value = 1
        spiclk.value = 0
        adcout <<= 1
        if i>0 and spimiso.value == 1:
            adcout |= 0x1
    spics.value = 1
    return adcout

# SPI通信用の入出力を定義
spiclk = DigitalOutputDevice(11)
spimosi = DigitalOutputDevice(10)
spimiso = DigitalInputDevice(9)
spics = DigitalOutputDevice(8)

try:
    while True:
        inputVal0 = readadc(0, spiclk, spimosi, spimiso, spics)
        print(inputVal0)
        sleep(0.2)

except KeyboardInterrupt:
    pass

spiclk.close()
spimosi.close()
spimiso.close()
spics.close()
