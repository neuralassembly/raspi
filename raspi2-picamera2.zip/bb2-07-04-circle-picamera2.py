# -*- coding: utf-8 -*-
import cv2
from picamera2 import Picamera2

camver = 1
(w, h)=(640, 480)

picam2 = Picamera2()
try:
    # camver=1 or camver=2
    preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[3])
except IndexError:
    try:
        camver=3
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)}, raw=picam2.sensor_modes[2])
    except IndexError:
        camver=0
        preview_config = picam2.create_preview_configuration({'format': 'XRGB8888', 'size': (w, h)})
picam2.configure(preview_config)
picam2.start()

blurval = min(int(16*(w/640)), 24)
blurval = blurval + (1 - blurval%2)
mincdist = int(100*(w/640))
mincradius = int(10*(w/640))
maxcradius = int(200*(w/640))
try:
    while True:
        frame = picam2.capture_array()

        # 映像データをグレースケール画像grayに変換
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # ガウシアンぼかしを適用して、認識精度を上げる
        blur = cv2.GaussianBlur(gray, (blurval,blurval), 0)
        # ハフ変換を適用し、映像内の円を探す
        circles = cv2.HoughCircles(blur, cv2.HOUGH_GRADIENT,
              dp=1, minDist=mincdist, param1=120, param2=40,
              minRadius=mincradius, maxRadius=maxcradius)

        if circles is not None:
            for c in circles[0]:
                # 見つかった円の上に赤い円を元の映像(frame)上に描画
                # c[0]:x座標, c[1]:y座標, c[2]:半径
                cv2.circle(frame, (int(c[0]),int(c[1])), int(c[2]), (0,0,255), 2)

        # frameをウインドウに表示
        cv2.imshow('frame', frame)

        # "q"を入力でアプリケーション終了
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    pass

cv2.destroyAllWindows()
